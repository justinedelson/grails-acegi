this directory is for collecting

- the webtest XML  result file
- the webtest HTML result overview
- all lastresponse fliles captured when running webtest