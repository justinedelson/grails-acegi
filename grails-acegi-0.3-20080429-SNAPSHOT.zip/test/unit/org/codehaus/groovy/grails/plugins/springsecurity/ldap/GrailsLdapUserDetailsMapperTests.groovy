package org.codehaus.groovy.grails.plugins.springsecurity.ldap

class GrailsLdapUserDetailsMapperTests extends GroovyTestCase {
	void testSomething() {
		
	}
}