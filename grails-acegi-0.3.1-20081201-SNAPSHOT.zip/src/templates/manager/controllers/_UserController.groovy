${personClassImport}
${authorityClassImport}

/**
 * User controller.
 */
class ${personClassName}Controller {

	def authenticateService

	// the delete, save and update actions only accept POST requests
	def allowedMethods = [delete: 'POST', save: 'POST', update: 'POST']

	def index = {
		redirect(action: list, params: params)
	}

	def list = {
		if (!params.max) {
			params.max = 10
		}
		[personList: ${personClassName}.list(params)]
	}

	def show = {
		[person: ${personClassName}.get(params.id)]
	}

	/**
	 * Person delete action. Before removing an existing person,
	 * he should be removed from those authorities which he is involved.
	 */
	def delete = {

		def person = ${personClassName}.get(params.id)
		if (person) {
			def authPrincipal = authenticateService.principal()
			//avoid self-delete if the logged-in user is an admin
			if (!(authPrincipal instanceof String) && authPrincipal.username == person.username) {
				flash.message = "You can not delete yourself, please login as another admin and try again"
			}
			else {
				//first, delete this person from People_Authorities table.
				${authorityClassName}.findAll().each { it.removeFromPeople(person) }
				person.delete()
				flash.message = "${personClassName} \${params.id} deleted."
			}
		}
		else {
			flash.message = "${personClassName} not found with id \${params.id}"
		}

		redirect(action: list)
	}

	def edit = {

		def person = ${personClassName}.get(params.id)
		if (!person) {
			flash.message = "${personClassName} not found with id \${params.id}"
			redirect(action: list)
			return
		}

		[person: person, authorityList: ${authorityClassName}.list()]
	}

	/**
	 * Person update action.
	 */
	def update = {

		def person = ${personClassName}.get(params.id)
		if (!person) {
			flash.message = "${personClassName} not found with id \${params.id}"
			redirect(action: edit, id: params.id)
			return
		}

		def oldPassword = person.passwd
		person.properties = params
		if (!params.passwd.equals(oldPassword)) {
			person.passwd = authenticateService.encodePassword(params.passwd)
		}
		if (person.save()) {
			${authorityClassName}.findAll().each { it.removeFromPeople(person) }
			addRoles(person)
			redirect(action: show, id: person.id)
		}
		else {
			render(view: 'edit', model: [person: person, authorityList: ${authorityClassName}.list()])
		}
	}

	def create = {
		def person = new ${personClassName}()
		person.properties = params
		[person: person, authorityList: ${authorityClassName}.list()]
	}

	/**
	 * Person save action.
	 */
	def save = {

		def person = new ${personClassName}()
		person.properties = params
		person.passwd = authenticateService.encodePassword(params.passwd)
		if (person.save()) {
			addRoles(person)
			redirect(action: show, id: person.id)
		}
		else {
			render(view: 'create', model: [authorityList: ${authorityClassName}.list(), person: person])
		}
	}

	private void addRoles(person) {
		for (String key in params.keySet()) {
			if (key.contains('ROLE') && 'on' == params.get(key)) {
				${authorityClassName}.findByAuthority(key).addToPeople(person)
			}
		}
	}
}
