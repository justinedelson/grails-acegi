// Cobertura code coverage
coverage {
	exclusions = [
		"**/*Tests.*",
		'**/AbstractSecurityTest.*'
	]
}
